/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureRectangle {

	public static final int GL_TEXTURE_RECTANGLE_EXT = 0x84F5,
		GL_TEXTURE_BINDING_RECTANGLE_EXT = 0x84F6,
		GL_PROXY_TEXTURE_RECTANGLE_EXT = 0x84F7,
		GL_MAX_RECTANGLE_TEXTURE_SIZE_EXT = 0x84F8;

	private EXTTextureRectangle() {}
}
