/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ATITextureCompression3DC {

	public static final int GL_COMPRESSED_LUMINANCE_ALPHA_3DC_ATI = 0x8837;

	private ATITextureCompression3DC() {}
}
