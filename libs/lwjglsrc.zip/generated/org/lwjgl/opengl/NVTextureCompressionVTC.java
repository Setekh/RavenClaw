/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVTextureCompressionVTC {

	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of TexImage3D and
	 *  CompressedTexImage3DARB and the &lt;format&gt; parameter of
	 *  CompressedTexSubImage2DARB:
	 */
	public static final int GL_COMPRESSED_RGB_S3TC_DXT1_EXT = 0x83F0,
		GL_COMPRESSED_RGBA_S3TC_DXT1_EXT = 0x83F1,
		GL_COMPRESSED_RGBA_S3TC_DXT3_EXT = 0x83F2,
		GL_COMPRESSED_RGBA_S3TC_DXT5_EXT = 0x83F3;

	private NVTextureCompressionVTC() {}
}
