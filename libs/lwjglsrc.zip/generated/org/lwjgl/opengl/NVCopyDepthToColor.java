/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVCopyDepthToColor {

	public static final int GL_DEPTH_STENCIL_TO_RGBA_NV = 0x886E,
		GL_DEPTH_STENCIL_TO_BGRA_NV = 0x886F;

	private NVCopyDepthToColor() {}
}
