/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class APPLEAuxDepthStencil {

	/**
	 * Accepted by the &lt;pname&gt; parameter of GetIntegerv. 
	 */
	public static final int GL_AUX_DEPTH_STENCIL_APPLE = 0x8A14;

	private APPLEAuxDepthStencil() {}
}
